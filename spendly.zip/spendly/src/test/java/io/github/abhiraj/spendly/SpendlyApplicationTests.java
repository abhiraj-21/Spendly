package io.github.abhiraj.spendly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpendlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
