package io.github.abhiraj.spendly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpendlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpendlyApplication.class, args);
	}

}
